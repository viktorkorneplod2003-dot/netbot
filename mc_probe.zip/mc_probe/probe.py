"""Одна последовательная проверка с одним TCP-соединением."""

import logging
import socket
import struct
import time
import uuid

from protocol.login import inspect_login
from protocol.packet import set_remaining
from protocol.status import status_ping
from protocol.varint import ProtocolError
from stats import Stats

LOGGER = logging.getLogger(__name__)


def probe_once(
    *, family: int, address: tuple, host: str, port: int,
    protocol: int | None, nickname: str, player_uuid: uuid.UUID,
    timeout_sec: float, stats: Stats,
) -> int | None:
    """Выполняет Status либо Login без переподключений и повторов."""
    stats.total += 1
    deadline = time.monotonic() + timeout_sec
    try:
        with socket.socket(family, socket.SOCK_STREAM) as sock:
            set_remaining(sock, deadline)
            sock.connect(address)
            if protocol is None:
                detected, name, rtt_ms = status_ping(sock, host, port, deadline)
                stats.ok_ping += 1
                stats.rtt_ms.append(rtt_ms)
                LOGGER.info("Status: version=%r protocol=%d rtt_ms=%.3f",
                            name, detected, rtt_ms)
                return detected
            outcome, reason = inspect_login(
                sock, host, port, protocol, nickname, player_uuid,
                deadline, stats.mark_login,
            )
            if outcome == "encryption":
                stats.reached_encryption += 1
                LOGGER.info("Получен Encryption Request")
            elif outcome == "login_success":
                stats.login_success_seen += 1
                LOGGER.info("Получен Login Success; соединение закрывается")
            else:
                assert reason is not None
                stats.disconnect_by_reason[reason] += 1
                LOGGER.info("Disconnect: %s", reason)
    except (OSError, ProtocolError, struct.error) as exc:
        error_type = type(exc).__name__
        stats.errors_by_type[error_type] += 1
        LOGGER.warning("Проверка завершилась ошибкой %s: %s", error_type, exc)
    return protocol
