"""Локальные проверки обмена без внешних серверов."""

from contextlib import contextmanager
import json
import logging
from pathlib import Path
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import zlib

import yaml

from main import load_config
from probe import probe_once
from protocol.login import offline_uuid
from protocol.packet import MAX_PACKET, frame, recv_packet, send_data
from protocol.varint import (
    ProtocolError, _self_check, decode_string, decode_varint,
    encode_string, encode_varint,
)
from stats import Stats


@contextmanager
def server(handler):
    """Запускает одноразовый сервер только на loopback-интерфейсе."""
    failures = []
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        listener.listen(1)
        listener.settimeout(3)

        def serve():
            try:
                connection, _ = listener.accept()
                with connection:
                    handler(connection)
            except BaseException as exc:
                failures.append(exc)

        thread = threading.Thread(target=serve, daemon=True)
        thread.start()
        try:
            yield listener.getsockname()
        finally:
            thread.join(4)
            if thread.is_alive():
                raise AssertionError("Локальный сервер не завершился")
            if failures:
                raise failures[0]


def read_login(connection):
    """Проверяет поля двух исходящих пакетов Login."""
    deadline = time.monotonic() + 2
    packet_id, payload = recv_packet(connection, deadline)
    assert packet_id == 0
    protocol, offset = decode_varint(payload)
    assert protocol == 769
    host, offset = decode_string(payload, offset)
    assert host == "127.0.0.1"
    assert int.from_bytes(payload[offset:offset + 2], "big") > 0
    state, end = decode_varint(payload, offset + 2)
    assert state == 2 and end == len(payload)
    packet_id, payload = recv_packet(connection, deadline)
    assert packet_id == 0
    name, offset = decode_string(payload)
    assert name == "mc_probe"
    assert payload[offset:] == offline_uuid(name).bytes


class ProbeTests(unittest.TestCase):
    """Проверяет независимые результаты и ограничение времени."""

    def setUp(self):
        """Приглушает ожидаемые сетевые ошибки в тестах."""
        logging.disable(logging.CRITICAL)

    def tearDown(self):
        """Восстанавливает логирование."""
        logging.disable(logging.NOTSET)

    def run_probe(self, address, protocol=769, timeout=1):
        """Вызывает одну проверку и возвращает её метрики."""
        stats = Stats()
        detected = probe_once(
            family=socket.AF_INET, address=address, host="127.0.0.1",
            port=address[1], protocol=protocol, nickname="mc_probe",
            player_uuid=offline_uuid("mc_probe"), timeout_sec=timeout,
            stats=stats,
        )
        self.assertEqual(stats.total, 1)
        return detected, stats

    def test_primitives(self):
        """Проверяет граничные значения примитивов."""
        _self_check()

    def test_status(self):
        """Проверяет Status Response и точное эхо Ping/Pong."""
        def respond(connection):
            deadline = time.monotonic() + 2
            packet_id, payload = recv_packet(connection, deadline)
            self.assertEqual(packet_id, 0)
            protocol, _ = decode_varint(payload)
            self.assertEqual(protocol, -1)
            self.assertEqual(payload[-1], 1)
            self.assertEqual(recv_packet(connection, deadline), (0, b""))
            response = json.dumps({"version": {"name": "test", "protocol": 769}})
            send_data(connection, frame(0, encode_string(response)), deadline)
            packet_id, payload = recv_packet(connection, deadline)
            self.assertEqual(packet_id, 1)
            self.assertEqual(len(payload), 8)
            send_data(connection, frame(1, payload), deadline)
        with server(respond) as address:
            detected, stats = self.run_probe(address, protocol=None)
        self.assertEqual(detected, 769)
        self.assertEqual(stats.ok_ping, 1)
        self.assertEqual(stats.reached_login, 0)
        self.assertIsNotNone(stats.snapshot()["rtt_ms_p95"])

    def test_login_outcomes(self):
        """Проверяет раздельный учёт Disconnect, Encryption и Success."""
        for packet_id in (0, 1, 2):
            with self.subTest(packet_id=packet_id):
                def respond(connection):
                    read_login(connection)
                    payload = encode_string('{"text":"Test reason"}') if packet_id == 0 else b""
                    send_data(connection, frame(packet_id, payload), time.monotonic() + 2)
                with server(respond) as address:
                    _, stats = self.run_probe(address)
                self.assertEqual(stats.reached_login, 1)
                self.assertEqual(stats.reached_encryption, int(packet_id == 1))
                self.assertEqual(stats.login_success_seen, int(packet_id == 2))
                self.assertEqual(sum(stats.disconnect_by_reason.values()), int(packet_id == 0))
                self.assertFalse(stats.errors_by_type)

    def test_compression(self):
        """Проверяет Set Compression и последующий сжатый пакет."""
        def respond(connection):
            read_login(connection)
            body = encode_varint(2) + b"test"
            compressed = encode_varint(len(body)) + zlib.compress(body)
            data = frame(3, encode_varint(1)) + encode_varint(len(compressed)) + compressed
            send_data(connection, data, time.monotonic() + 2)
        with server(respond) as address:
            _, stats = self.run_probe(address)
        self.assertEqual(stats.login_success_seen, 1)
        self.assertFalse(stats.errors_by_type)

    def test_timeout_and_eof(self):
        """Проверяет общий таймаут и закрытие сервера."""
        def silent(connection):
            read_login(connection)
            time.sleep(0.25)
        started = time.monotonic()
        with server(silent) as address:
            _, stats = self.run_probe(address, timeout=0.1)
        self.assertLess(time.monotonic() - started, 1)
        self.assertEqual(stats.errors_by_type["TimeoutError"], 1)
        with server(read_login) as address:
            _, stats = self.run_probe(address)
        self.assertEqual(stats.errors_by_type["ConnectionError"], 1)

    def test_packet_limit(self):
        """Отклоняет чрезмерную длину до выделения тела пакета."""
        client, peer = socket.socketpair()
        with client, peer:
            peer.sendall(encode_varint(MAX_PACKET + 1))
            with self.assertRaises(ProtocolError):
                recv_packet(client, time.monotonic() + 1)

    def test_config_limits(self):
        """Проверяет жёсткие лимиты и неверные типы YAML."""
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.yaml"
            path.write_text("target: {}\nchecks: {}\n", encoding="utf-8")
            self.assertEqual(load_config(path)["max_checks"], 5)
            for section, key, value in (
                ("checks", "max_checks", 101),
                ("checks", "max_checks", True),
                ("checks", "interval_sec", 0),
                ("checks", "timeout_sec", 31),
                ("target", "explicit_protocol", "26X"),
                ("logging", "level", []),
            ):
                config = {"target": {}, "checks": {}}
                config.setdefault(section, {})[key] = value
                path.write_text(yaml.safe_dump(config), encoding="utf-8")
                with self.assertRaises(ValueError):
                    load_config(path)

    @unittest.skipIf(sys.platform == "win32", "POSIX-сигнал")
    def test_cli_graceful_shutdown(self):
        """SIGTERM завершает текущую проверку и сохраняет итоговый JSON."""
        connected = threading.Event()
        release = threading.Event()

        def respond(connection):
            read_login(connection)
            connected.set()
            if not release.wait(2):
                raise AssertionError("Не получен сигнал завершения теста")
            send_data(connection, frame(1), time.monotonic() + 2)

        project = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as directory:
            with server(respond) as address:
                config = {
                    "target": {"host": "127.0.0.1", "port": address[1],
                               "explicit_protocol": 769},
                    "checks": {"max_checks": 3, "interval_sec": 1, "timeout_sec": 3},
                }
                path = Path(directory) / "config.yaml"
                path.write_text(yaml.safe_dump(config), encoding="utf-8")
                process = subprocess.Popen(
                    [sys.executable, str(project / "main.py"), "--config", str(path)],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                )
                try:
                    self.assertTrue(connected.wait(2))
                    process.send_signal(signal.SIGTERM)
                    # Даём обработчику сигнала установить флаг до ответа сервера.
                    time.sleep(0.05)
                    release.set()
                    stdout, stderr = process.communicate(timeout=4)
                    self.assertEqual(process.returncode, 0, stderr)
                    result = json.loads(stdout.splitlines()[-1])
                    self.assertEqual(result["total"], 1)
                    self.assertEqual(result["reached_encryption"], 1)
                finally:
                    release.set()
                    if process.poll() is None:
                        process.kill()
                        process.communicate()


if __name__ == "__main__":
    unittest.main()
