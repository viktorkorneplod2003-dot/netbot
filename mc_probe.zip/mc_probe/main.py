"""CLI последовательного тестера Minecraft Java."""

import argparse
import ipaddress
import json
import logging
import math
from pathlib import Path
import re
import signal
import socket
import sys
import threading
import uuid

import yaml

from probe import probe_once
from protocol.login import MIN_PROTOCOL, offline_uuid
from stats import Stats

LOGGER = logging.getLogger("mc_probe")


class OutputFormatter(logging.Formatter):
    """Выводит финальный JSON без префикса логирования."""

    def format(self, record: logging.LogRecord) -> str:
        """Форматирует обычную запись либо финальную сводку."""
        if getattr(record, "final_json", False):
            return record.getMessage()
        return super().format(record)


def require_mapping(value: object, name: str) -> dict:
    """Проверяет, что раздел YAML является отображением."""
    if not isinstance(value, dict):
        raise ValueError(f"{name}: ожидается YAML mapping")
    return value


def reject_unknown(data: dict, allowed: set[str], name: str) -> None:
    """Отклоняет неизвестные поля и опечатки."""
    unknown = set(data) - allowed
    if unknown:
        raise ValueError(f"{name}: неизвестные поля {unknown}")


def number(value: object, name: str, minimum: float, maximum: float) -> float:
    """Проверяет конечное число в заданных пределах."""
    if (type(value) not in (int, float)
            or not minimum <= value <= maximum
            or not math.isfinite(value)):
        raise ValueError(f"{name}: требуется число {minimum}..{maximum}")
    return float(value)


def load_config(path: Path) -> dict:
    """Загружает конфигурацию и проверяет жёсткие пределы."""
    if path.stat().st_size > 65536:
        raise ValueError("Конфигурация превышает 64 КиБ")
    with path.open(encoding="utf-8") as source:
        root = require_mapping(yaml.safe_load(source), "config")
    reject_unknown(root, {"target", "checks", "login", "logging"}, "config")
    target = require_mapping(root.get("target"), "target")
    checks = require_mapping(root.get("checks"), "checks")
    login = require_mapping(root.get("login", {}), "login")
    logs = require_mapping(root.get("logging", {}), "logging")
    reject_unknown(target, {"host", "port", "explicit_protocol"}, "target")
    reject_unknown(checks, {"max_checks", "interval_sec", "timeout_sec"}, "checks")
    reject_unknown(login, {"nickname", "uuid"}, "login")
    reject_unknown(logs, {"level", "file"}, "logging")
    host = target.get("host", "127.0.0.1")
    if not isinstance(host, str) or not host or "\x00" in host:
        raise ValueError("target.host: требуется непустой адрес")
    try:
        host = str(ipaddress.ip_address(host))
    except ValueError:
        host = host.encode("idna").decode("ascii")
    if len(host) > 255:
        raise ValueError("target.host превышает 255 символов")
    port = target.get("port", 25565)
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError("target.port: требуется целое 1..65535")
    protocol = target.get("explicit_protocol")
    if protocol is not None and (
        type(protocol) is not int or not MIN_PROTOCOL <= protocol <= 2147483647
    ):
        raise ValueError("explicit_protocol: null либо целое 764..2147483647")
    max_checks = checks.get("max_checks", 5)
    if type(max_checks) is not int or not 1 <= max_checks <= 100:
        raise ValueError("max_checks: требуется целое 1..100")
    interval = number(checks.get("interval_sec", 5), "interval_sec", 1, 3600)
    timeout = number(checks.get("timeout_sec", 5), "timeout_sec", 0.1, 30)
    nickname = login.get("nickname", "mc_probe")
    if not isinstance(nickname, str) or not re.fullmatch(r"[A-Za-z0-9_]{1,16}", nickname):
        raise ValueError("nickname: 1..16 символов A-Z, a-z, 0-9 или _")
    uuid_value = login.get("uuid")
    if uuid_value is not None and not isinstance(uuid_value, str):
        raise ValueError("login.uuid: строка UUID либо null")
    player_uuid = uuid.UUID(uuid_value) if uuid_value is not None else offline_uuid(nickname)
    level = logs.get("level", "INFO")
    if not isinstance(level, str) or level not in {
        "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"
    }:
        raise ValueError("Некорректный logging.level")
    logfile = logs.get("file", "mc_probe.log")
    if not isinstance(logfile, str) or not logfile:
        raise ValueError("logging.file: требуется путь")
    logpath = Path(logfile)
    if not logpath.is_absolute():
        logpath = path.parent / logpath
    return {
        "host": host, "port": port, "protocol": protocol,
        "max_checks": max_checks, "interval_sec": interval,
        "timeout_sec": timeout, "nickname": nickname,
        "player_uuid": player_uuid, "loglevel": level, "logpath": logpath,
    }


def configure_logging(level: str, path: Path) -> None:
    """Настраивает журнал в файл и stdout."""
    formatter = OutputFormatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    file_handler = logging.FileHandler(path, encoding="utf-8")
    console_handler = logging.StreamHandler(sys.stdout)
    for handler in (file_handler, console_handler):
        handler.setFormatter(formatter)
        handler.setLevel(level)
    root = logging.getLogger()
    for handler in root.handlers[:]:
        root.removeHandler(handler)
        handler.close()
    root.setLevel(level)
    root.addHandler(file_handler)
    root.addHandler(console_handler)


def main() -> int:
    """Проверяет конфигурацию, запускает проверки и выводит итог."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s",
                        stream=sys.stdout)
    parser = argparse.ArgumentParser(
        description="Последовательные проверки Minecraft Java 1.20.2+"
    )
    parser.add_argument("--config", type=Path, default=Path("config.yaml"))
    args = parser.parse_args()
    stats = Stats()
    stop = threading.Event()

    def request_stop(signum: int, frame: object) -> None:
        """Запрашивает остановку после текущей проверки."""
        stop.set()

    previous_handlers = {}
    for signum in (signal.SIGINT, signal.SIGTERM):
        previous_handlers[signum] = signal.signal(signum, request_stop)
    exit_code = 0
    try:
        config = load_config(args.config.resolve())
        configure_logging(config["loglevel"], config["logpath"])
        # DNS выполняется один раз до проверок; системный DNS имеет
        # собственные таймауты. Внутри проверки действует общий TCP-дедлайн.
        addresses = socket.getaddrinfo(
            config["host"], config["port"], family=socket.AF_UNSPEC,
            type=socket.SOCK_STREAM, proto=socket.IPPROTO_TCP,
        )
        if not addresses:
            raise OSError("Не найден адрес сервера")
        # Один адрес без обхода списка и повторных connect.
        family, _, _, _, address = addresses[0]
        protocol = config["protocol"]
        for _ in range(config["max_checks"]):
            if stop.is_set():
                break
            protocol = probe_once(
                family=family, address=address, host=config["host"],
                port=config["port"], protocol=protocol,
                nickname=config["nickname"], player_uuid=config["player_uuid"],
                timeout_sec=config["timeout_sec"], stats=stats,
            )
            LOGGER.info("Метрики: %s", json.dumps(stats.snapshot(), ensure_ascii=True))
            if protocol is None:
                LOGGER.error("Protocol ID не определён; проверки остановлены")
                exit_code = 1
                break
            if protocol < MIN_PROTOCOL:
                LOGGER.error("Login для protocol=%d не поддерживается", protocol)
                exit_code = 1
                break
            if stats.total == config["max_checks"]:
                break
            if stop.wait(config["interval_sec"]):
                break
        if stats.errors_by_type:
            exit_code = 1
    except (OSError, ValueError, yaml.YAMLError) as exc:
        stats.errors_by_type[type(exc).__name__] += 1
        LOGGER.error("Ошибка запуска: %s", exc)
        exit_code = 2
    finally:
        LOGGER.critical(
            json.dumps(stats.snapshot(), ensure_ascii=True, allow_nan=False),
            extra={"final_json": True},
        )
        for signum, previous in previous_handlers.items():
            signal.signal(signum, previous)
        logging.shutdown()
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
