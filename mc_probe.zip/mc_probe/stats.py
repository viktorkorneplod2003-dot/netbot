"""Накопление независимых метрик проверок."""

from collections import Counter
from dataclasses import dataclass, field
import math


@dataclass
class Stats:
    """Хранит счётчики этапов и RTT успешных Ping/Pong."""

    total: int = 0
    ok_ping: int = 0
    reached_login: int = 0
    reached_encryption: int = 0
    login_success_seen: int = 0
    disconnect_by_reason: Counter[str] = field(default_factory=Counter)
    errors_by_type: Counter[str] = field(default_factory=Counter)
    rtt_ms: list[float] = field(default_factory=list)

    def mark_login(self) -> None:
        """Отмечает полностью отправленный Login Start."""
        self.reached_login += 1

    def percentile(self, percentile: float) -> float | None:
        """Возвращает квантиль методом ближайшего ранга."""
        if not self.rtt_ms:
            return None
        ordered = sorted(self.rtt_ms)
        index = max(0, math.ceil(len(ordered) * percentile) - 1)
        return round(ordered[index], 3)

    def snapshot(self) -> dict[str, object]:
        """Создаёт JSON-совместимый снимок."""
        return {
            "total": self.total,
            "ok_ping": self.ok_ping,
            "reached_login": self.reached_login,
            "reached_encryption": self.reached_encryption,
            "login_success_seen": self.login_success_seen,
            "disconnect_by_reason": dict(self.disconnect_by_reason),
            "errors_by_type": dict(self.errors_by_type),
            "rtt_ms_p50": self.percentile(0.50),
            "rtt_ms_p95": self.percentile(0.95),
        }
