"""Кодирование и декодирование примитивов Minecraft."""

import struct


class ProtocolError(ValueError):
    """Некорректные данные протокола."""


def encode_varint(value: int) -> bytes:
    """Кодирует знаковый 32-битный VarInt."""
    if type(value) is not int or not -(1 << 31) <= value < (1 << 31):
        raise ValueError("VarInt вне диапазона int32")
    value &= 0xFFFFFFFF
    result = bytearray()
    while True:
        byte = value & 0x7F
        value >>= 7
        result.append(byte | (0x80 if value else 0))
        if not value:
            return bytes(result)


def decode_varint(data: bytes, offset: int = 0) -> tuple[int, int]:
    """Возвращает значение VarInt и смещение следующего байта."""
    if not 0 <= offset <= len(data):
        raise ProtocolError("Некорректное смещение")
    value = 0
    for index in range(5):
        if offset >= len(data):
            raise ProtocolError("Незавершённый VarInt")
        byte = data[offset]
        offset += 1
        if index == 4 and byte & 0xF0:
            raise ProtocolError("Переполнение VarInt")
        value |= (byte & 0x7F) << (7 * index)
        if not byte & 0x80:
            if value & (1 << 31):
                value -= 1 << 32
            return value, offset
    raise ProtocolError("Слишком длинный VarInt")


def encode_string(value: str, max_chars: int = 32767) -> bytes:
    """Кодирует строку UTF-8 с длиной в формате VarInt."""
    if len(value.encode("utf-16-be")) // 2 > max_chars:
        raise ValueError("Строка превышает допустимую длину")
    encoded = value.encode("utf-8")
    if len(encoded) > max_chars * 3:
        raise ValueError("Слишком длинная строка UTF-8")
    return encode_varint(len(encoded)) + encoded


def decode_string(data: bytes, offset: int = 0,
                  max_chars: int = 32767) -> tuple[str, int]:
    """Декодирует строку UTF-8 и возвращает новое смещение."""
    size, offset = decode_varint(data, offset)
    if size < 0 or size > max_chars * 3 or offset + size > len(data):
        raise ProtocolError("Некорректная длина строки")
    try:
        value = data[offset:offset + size].decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ProtocolError("Некорректный UTF-8") from exc
    if len(value.encode("utf-16-be")) // 2 > max_chars:
        raise ProtocolError("Слишком длинная строка")
    return value, offset + size


def encode_ushort(value: int) -> bytes:
    """Кодирует беззнаковое 16-битное число."""
    return struct.pack(">H", value)


def decode_ushort(data: bytes) -> int:
    """Декодирует ровно два байта."""
    return struct.unpack(">H", data)[0]


def encode_long(value: int) -> bytes:
    """Кодирует знаковое 64-битное число."""
    return struct.pack(">q", value)


def decode_long(data: bytes) -> int:
    """Декодирует ровно восемь байт."""
    return struct.unpack(">q", data)[0]


def _self_check() -> None:
    """Проверяет границы и отклонение повреждённых данных."""
    for value in (0, 1, 127, 128, 255, 2147483647, -1, -2147483648):
        encoded = encode_varint(value)
        assert decode_varint(encoded) == (value, len(encoded))
    encoded = encode_string("Проверка")
    assert decode_string(encoded) == ("Проверка", len(encoded))
    for malformed in (b"\x80", b"\xff\xff\xff\xff\x10"):
        try:
            decode_varint(malformed)
        except ProtocolError:
            continue
        raise AssertionError("Повреждённый VarInt принят")


if __name__ == "__main__":
    _self_check()
