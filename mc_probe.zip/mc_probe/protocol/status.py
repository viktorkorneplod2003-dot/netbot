"""Server List Ping и формирование Handshake."""

import json
import secrets
import socket
import time

from .packet import frame, recv_packet, send_data
from .varint import (
    ProtocolError, decode_long, decode_string, encode_long,
    encode_string, encode_ushort, encode_varint,
)


def handshake(protocol: int, host: str, port: int, next_state: int) -> bytes:
    """Формирует Handshake для Status или Login."""
    if next_state not in (1, 2):
        raise ValueError("Недопустимое следующее состояние")
    payload = (encode_varint(protocol) + encode_string(host, 255)
               + encode_ushort(port) + encode_varint(next_state))
    return frame(0x00, payload)


def status_ping(sock: socket.socket, host: str, port: int,
                deadline: float) -> tuple[int, str, float]:
    """Получает версию и измеряет RTT обмена Ping/Pong."""
    send_data(sock, handshake(-1, host, port, 1) + frame(0x00), deadline)
    packet_id, payload = recv_packet(sock, deadline)
    if packet_id != 0x00:
        raise ProtocolError("Ожидался Status Response")
    text, offset = decode_string(payload)
    if offset != len(payload):
        raise ProtocolError("Лишние данные Status Response")
    try:
        response = json.loads(text)
    except (ValueError, RecursionError) as exc:
        raise ProtocolError("Некорректный JSON Status Response") from exc
    version = response.get("version") if isinstance(response, dict) else None
    if not isinstance(version, dict):
        raise ProtocolError("Отсутствует объект version")
    protocol = version.get("protocol")
    name = version.get("name")
    if type(protocol) is not int or not 0 <= protocol <= 2147483647:
        raise ProtocolError("Некорректный version.protocol")
    if not isinstance(name, str):
        raise ProtocolError("Некорректный version.name")
    token = secrets.randbits(63)
    started = time.monotonic()
    send_data(sock, frame(0x01, encode_long(token)), deadline)
    packet_id, payload = recv_packet(sock, deadline)
    if packet_id != 0x01 or len(payload) != 8:
        raise ProtocolError("Ожидался Pong с восемью байтами")
    if decode_long(payload) != token:
        raise ProtocolError("Значение Pong не совпадает с Ping")
    return protocol, name, (time.monotonic() - started) * 1000
