"""Проверка состояния Login без перехода в Configuration."""

import hashlib
import json
import socket
import uuid
from collections.abc import Callable

from .packet import frame, recv_packet, send_data
from .status import handshake
from .varint import ProtocolError, decode_string, decode_varint, encode_string

MIN_PROTOCOL = 764


def offline_uuid(nickname: str) -> uuid.UUID:
    """Вычисляет UUID по алгоритму Java для offline-профиля."""
    digest = hashlib.md5(
        ("OfflinePlayer:" + nickname).encode("utf-8"),
        usedforsecurity=False,
    ).digest()
    return uuid.UUID(bytes=digest, version=3)


def login_start(nickname: str, player_uuid: uuid.UUID) -> bytes:
    """Формирует Login Start: имя и обязательные 16 байт UUID."""
    return frame(0x00, encode_string(nickname, 16) + player_uuid.bytes)


def inspect_login(
    sock: socket.socket, host: str, port: int, protocol: int,
    nickname: str, player_uuid: uuid.UUID, deadline: float,
    on_login_sent: Callable[[], None],
) -> tuple[str, str | None]:
    """Отправляет вход и классифицирует первый конечный ответ."""
    if protocol < MIN_PROTOCOL:
        raise ProtocolError("Поддерживается Login Start для 1.20.2+")
    send_data(sock, handshake(protocol, host, port, 2)
              + login_start(nickname, player_uuid), deadline)
    on_login_sent()
    compression_threshold: int | None = None
    # Set Compression может предшествовать Login Success.
    for _ in range(2):
        packet_id, payload = recv_packet(sock, deadline, compression_threshold)
        if packet_id == 0x00:
            text, offset = decode_string(payload)
            if offset != len(payload):
                raise ProtocolError("Лишние данные Disconnect")
            try:
                reason = json.loads(text)
                canonical = json.dumps(reason, ensure_ascii=True, sort_keys=True,
                                       separators=(",", ":"), allow_nan=False)
            except (ValueError, RecursionError) as exc:
                raise ProtocolError("Некорректный JSON Disconnect") from exc
            return "disconnect", canonical
        if packet_id == 0x01:
            return "encryption", None
        if packet_id == 0x02:
            return "login_success", None
        if packet_id == 0x03 and compression_threshold is None:
            threshold, offset = decode_varint(payload)
            if offset != len(payload) or threshold < 0:
                raise ProtocolError("Некорректный Set Compression")
            compression_threshold = threshold
            continue
        raise ProtocolError(f"Неподдерживаемый пакет Login: 0x{packet_id:02x}")
    raise ProtocolError("Отсутствует конечный ответ Login")
