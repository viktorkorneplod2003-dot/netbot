"""Ограниченное чтение пакетов с общим сроком выполнения."""

import socket
import time
import zlib

from .varint import ProtocolError, decode_varint, encode_varint

MAX_PACKET = 1024 * 1024


def set_remaining(sock: socket.socket, deadline: float) -> None:
    """Устанавливает остаток общего бюджета времени проверки."""
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError("Истёк общий таймаут проверки")
    sock.settimeout(remaining)


def send_data(sock: socket.socket, data: bytes, deadline: float) -> None:
    """Отправляет данные в пределах общего таймаута."""
    set_remaining(sock, deadline)
    sock.sendall(data)


def frame(packet_id: int, payload: bytes = b"") -> bytes:
    """Создаёт пакет без включённого сжатия."""
    body = encode_varint(packet_id) + payload
    if len(body) > MAX_PACKET:
        raise ProtocolError("Слишком большой исходящий пакет")
    return encode_varint(len(body)) + body


def recv_exact(sock: socket.socket, size: int, deadline: float) -> bytes:
    """Читает ровно size байт; EOF считается ошибкой."""
    if not 0 <= size <= MAX_PACKET:
        raise ProtocolError("Недопустимый размер чтения")
    result = bytearray()
    while len(result) < size:
        set_remaining(sock, deadline)
        chunk = sock.recv(size - len(result))
        if not chunk:
            raise ConnectionError("Сервер закрыл соединение")
        result.extend(chunk)
    return bytes(result)


def _recv_varint(sock: socket.socket, deadline: float) -> int:
    """Читает VarInt без чтения байтов следующего поля."""
    encoded = bytearray()
    for _ in range(5):
        byte = recv_exact(sock, 1, deadline)[0]
        encoded.append(byte)
        if not byte & 0x80:
            return decode_varint(bytes(encoded))[0]
    raise ProtocolError("Слишком длинный VarInt длины пакета")


def recv_packet(sock: socket.socket, deadline: float,
                compression_threshold: int | None = None) -> tuple[int, bytes]:
    """Читает пакет и при необходимости ограниченно распаковывает его."""
    size = _recv_varint(sock, deadline)
    if not 1 <= size <= MAX_PACKET:
        raise ProtocolError("Некорректная длина пакета")
    body = recv_exact(sock, size, deadline)
    if compression_threshold is not None:
        unpacked_size, offset = decode_varint(body)
        compressed = body[offset:]
        if not 0 <= unpacked_size <= MAX_PACKET:
            raise ProtocolError("Некорректный размер после распаковки")
        if unpacked_size:
            if unpacked_size < compression_threshold:
                raise ProtocolError("Сжатый пакет меньше порога сжатия")
            try:
                decompressor = zlib.decompressobj()
                body = decompressor.decompress(compressed, unpacked_size + 1)
            except zlib.error as exc:
                raise ProtocolError("Некорректные сжатые данные") from exc
            if (len(body) != unpacked_size or not decompressor.eof
                    or decompressor.unused_data or decompressor.unconsumed_tail):
                raise ProtocolError("Некорректная длина сжатого пакета")
        else:
            body = compressed
            if len(body) >= compression_threshold:
                raise ProtocolError("Несжатый пакет превышает порог")
    packet_id, offset = decode_varint(body)
    if packet_id < 0:
        raise ProtocolError("Отрицательный ID пакета")
    return packet_id, body[offset:]
