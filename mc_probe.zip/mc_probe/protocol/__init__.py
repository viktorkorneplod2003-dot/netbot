"""Примитивы протокола Minecraft Java."""
